// import ballerina/io;

// import ballerina/sql;
import ballerinax/java.jdbc;
import ballerinax/kafka;

// Kafka consumer configuration for standard delivery requests
kafka:ConsumerConfiguration standardConsumerConfig = {
    groupId: "logistics-group",
    topics: ["standard_delivery"],
    pollingInterval: 1,
    autoCommit: false
};

// Kafka consumer configuration for express delivery requests
kafka:ConsumerConfiguration expressConsumerConfig = {
    groupId: "logistics-group",
    topics: ["express_delivery"],
    pollingInterval: 1,
    autoCommit: false
};

// Kafka consumer configuration for international delivery requests
kafka:ConsumerConfiguration internationalConsumerConfig = {
    groupId: "logistics-group",
    topics: ["international_delivery"],
    pollingInterval: 1,
    autoCommit: false
};

// Kafka producer configuration for sending responses
kafka:ProducerConfiguration producerConfig = {
    clientId: "logistics-producer",
    acks: "all",
    retryCount: 3
};

// Initialize the Kafka consumers
kafka:Consumer standardConsumer = check new ("localhost:9092", standardConsumerConfig);
kafka:Consumer expressConsumer = check new ("localhost:9092", expressConsumerConfig);
kafka:Consumer internationalConsumer = check new ("localhost:9092", internationalConsumerConfig);

// Initialize the Kafka producer
kafka:Producer kafkaProducer = check new ("localhost:9092", producerConfig);

// Initialize the database client
jdbc:Client dbClient = check new ("jdbc:postgresql://localhost:5432/logistics_db", "postgres", "postgres");

// Function to process messages
// function processMessage(kafka:ConsumerRecord[] records) {
//     foreach kafka:ConsumerRecord record in records {
//         // Parse the delivery request message
//         json request = check record.value.fromJsonString();

//         // Extract shipment details from the request
//         string shipmentType = check request.shipmentType.toString();
//         string pickupLocation = check request.pickupLocation.toString();
//         string deliveryLocation = check request.deliveryLocation.toString();
//         string preferredTimeSlot = check request.preferredTimeSlot.toString();
//         string firstName = check request.firstName.toString();
//         string lastName = check request.lastName.toString();
//         string contactNumber = check request.contactNumber.toString();

//         // Store customer information in the database
//         sql:ParameterizedQuery insertCustomerQuery = `INSERT INTO customers (first_name, last_name, contact_number) VALUES (${firstName}, ${lastName}, ${contactNumber}) RETURNING customer_id`;
//         sql:Integer customerId = check dbClient->execute(insertCustomerQuery);

//         // Store shipment details in the database
//         sql:ParameterizedQuery insertShipmentQuery = `INSERT INTO shipments (customer_id, shipment_type, pickup_location, delivery_location, preferred_time_slot, status) VALUES (${customerId}, ${shipmentType}, ${pickupLocation}, ${deliveryLocation}, ${preferredTimeSlot}, 'pending') RETURNING shipment_id`;
//         sql:Integer shipmentId = check dbClient->execute(insertShipmentQuery);

//         // Send a response to the client
//         string responseMessage = string `{"shipmentId": ${shipmentId}, "message": "Delivery request received and is being processed."}`;
//         kafka:Error? sendResult = kafkaProducer->send({
//             topic: "logistics_response",
//             value: responseMessage
//         });

//         if (sendResult is error) {
//             io:println("Error sending message to Kafka: ", sendResult);
//         } else {
//             io:println("Response sent to client successfully.");
//         }
//     }
// }

// public function main() {
//     // Start consuming messages from Kafka topics
//     check standardConsumer->poll(processMessage);
//     check expressConsumer->poll(processMessage);
//     check internationalConsumer->poll(processMessage);
// }
