CREATE DATABASE logistics_db;

CREATE TABLE customers (
    customer_id SERIAL PRIMARY KEY,
    first_name VARCHAR(255) NOT NULL,
    last_name VARCHAR(255) NOT NULL,
    contact_number VARCHAR(20) NOT NULL
);

CREATE TABLE shipments (
    shipment_id SERIAL PRIMARY KEY,
    customer_id INT REFERENCES customers(customer_id),
    shipment_type VARCHAR(50) NOT NULL,
    pickup_location VARCHAR(255) NOT NULL,
    delivery_location VARCHAR(255) NOT NULL,
    preferred_time_slot VARCHAR(255),
    status VARCHAR(50) NOT NULL
);

CREATE TABLE delivery_schedules (
    schedule_id SERIAL PRIMARY KEY,
    shipment_id INT REFERENCES shipments(shipment_id),
    pickup_time TIMESTAMP,
    delivery_time TIMESTAMP,
    tracking_information VARCHAR(255)
);